# Скрипт для получения списка аккаунтов Avito

## Установка

```bash
pip install -r requirements.txt
```

## Запуск

```bash
python get_accounts.py
```

---

Замените CLIENT_ID и CLIENT_SECRET на ваши.
